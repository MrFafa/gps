<div class='rd_metabox'>



<?php

$this->h_sidebar();

?>



<?php

$this->textarea(	'link',

				'Link for the sponsor </br> ex:</br>

				 http://www.google.com'

);

?>



</div>