/**
 * Loadpost
**/
jQuery(document).ready(function($) {
	"use strict";
	// The number of the next page to load (/page/x/).
	var pageNum = parseInt(pbd_alp.startPage) + 1;
	// The maximum number of pages the current query can return.
	var max = parseInt(pbd_alp.maxPages);
	// The link of the next page of posts.
	var nextLink = pbd_alp.nextLink;

});